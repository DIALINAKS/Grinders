import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { C, S } from '../theme';
import { Card, H2, Field, Label, Chips, Button, Body, Note } from '../components/ui';
import { MODELS, tierOf, canRegisterGrinder } from '../engine';

export default function RegisterGrinder({ tier, grinders, onRegister, onClose, onSeePlans }) {
  const [model, setModel] = useState('Mythos One');
  const [name, setName] = useState('');
  const [err, setErr] = useState('');
  const allowed = canRegisterGrinder(tier, grinders);
  const t = tierOf(tier);

  const add = () => {
    const n = name.trim() || (model === 'Other' ? '' : model);
    if (!n) { setErr('Give this grinder a name, e.g. Mahlkönig E65S.'); return; }
    if (grinders.some(g => g.name.trim().toLowerCase() === n.toLowerCase())) {
      setErr(`You already have a grinder called ${n}. Give this one a different name, e.g. "${n} – bar 2".`); return;
    }
    onRegister(n, model);
  };

  return (
    <Card>
      <H2>Register a grinder</H2>
      {!allowed ? (
        <>
          <Note>
            <Text style={{ fontWeight: '700' }}>The {t.label} plan includes 1 grinder. </Text>
            Every plan uses the same calibration engine. Business lets you register as many grinders as you need, each with its own coffees and calibration history.
          </Note>
          <Button title="See plans" onPress={onSeePlans} />
        </>
      ) : (
        <>
          <View>
            <Label>Model</Label>
            <Chips items={MODELS.map(m => ({ key: m, label: m }))} value={model} onChange={setModel} />
          </View>
          <Field label="Name (so you can tell grinders apart)" value={name} onChangeText={setName} keyboardType="default"
            placeholder={model === 'Other' ? 'e.g. Mahlkönig E65S' : `e.g. ${model} – bar 1`} width="full" />
          <Body muted>Known models come with their settings filled in. You can change them any time in Rules.</Body>
          {err ? <Text style={{ color: C.bad }}>{err}</Text> : null}
          <Button title="Register grinder" onPress={add} />
        </>
      )}
      <Button title="Close" kind="secondary" onPress={onClose} />
    </Card>
  );
}
