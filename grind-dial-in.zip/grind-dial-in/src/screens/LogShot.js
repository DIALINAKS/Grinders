import React, { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import { C, S } from '../theme';
import { Card, Field, Grid, Label, Segmented, Button, H2, Note } from '../components/ui';
import { checkDialEntry, dialMarks, rulesFor } from '../engine';

const LOADS = [{ value: 0, label: 'Quiet' }, { value: 1, label: 'Steady' }, { value: 2, label: 'Busy' }];
const TASTES = [{ value: 'sour', label: 'Sour' }, { value: 'balanced', label: 'Balanced' }, { value: 'bitter', label: 'Bitter' }, { value: '', label: 'Skip' }];
const num = v => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };

export default function LogShot({ grinder, coffee, lastShot, blocked, onSave, onSeePlans }) {
  const blank = () => ({
    bean: coffee || '', roast: lastShot ? lastShot.roast || '' : '', setting: '', doserTime: '',
    dose: lastShot && lastShot.dose != null ? String(lastShot.dose) : '', yield: '', time: '',
    groupTemp: lastShot && lastShot.groupTemp != null ? String(lastShot.groupTemp) : '',
    roomTemp: '', humidity: '', workload: lastShot && lastShot.workload != null ? lastShot.workload : 1, taste: '', notes: '',
  });
  const [f, setF] = useState(blank);
  const [err, setErr] = useState('');
  const [saved, setSaved] = useState(false);
  useEffect(() => { setF(blank()); setErr(''); }, [grinder && grinder.id, coffee]);
  const set = k => v => setF(p => ({ ...p, [k]: v }));

  const save = () => {
    const shot = {
      bean: f.bean.trim(), roast: f.roast.trim(), setting: num(f.setting), doserTime: num(f.doserTime), dose: num(f.dose),
      yield: num(f.yield), time: num(f.time), groupTemp: num(f.groupTemp), roomTemp: num(f.roomTemp), humidity: num(f.humidity),
      workload: f.workload, taste: f.taste, notes: f.notes.trim(),
    };
    const missing = [['bean', 'Coffee'], ['setting', 'Grind setting'], ['dose', 'Dose'], ['yield', 'Yield'], ['time', 'Extraction time']]
      .filter(([k]) => shot[k] === '' || shot[k] === null).map(x => x[1]);
    if (missing.length) { setErr('Add ' + missing.join(', ') + ' to save this shot.'); return; }
    const dialErr = checkDialEntry(shot.setting, dialMarks(rulesFor(grinder)));
    if (dialErr) { setErr(dialErr); return; }
    setErr('');
    onSave(shot);
    setF(p => ({ ...blank(), bean: shot.bean, dose: f.dose, groupTemp: f.groupTemp, workload: f.workload }));
    setSaved(true); setTimeout(() => setSaved(false), 2500);
  };

  return (
    <Card>
      <H2>Log a shot</H2>
      <Text style={{ color: C.muted }}>Grinder: <Text style={{ color: C.ink, fontWeight: '700' }}>{grinder.name}</Text></Text>
      {blocked === 'limit' ? (
        <Note tone="warn">You've saved 20 shots, the limit on the Free plan. Your shots, settings and predictions are all still here. Move to Pro to keep logging. It's free while we test.</Note>
      ) : null}
      {blocked === 'archived' ? (
        <Note tone="warn">This grinder is archived (read-only). Your plan includes 1 active grinder. You can still view its shots and predictions. Move to Business to use it again.</Note>
      ) : null}
      {blocked ? <Button title="See plans" onPress={onSeePlans} /> : null}
      <Grid>
        <Field label="Coffee" value={f.bean} onChangeText={set('bean')} keyboardType="default" placeholder="e.g. Rusty's Roast" width="full" />
        <Field label="Grind setting" value={f.setting} onChangeText={set('setting')} placeholder="As the dial reads" />
        <Field label="Doser time (s)" value={f.doserTime} onChangeText={set('doserTime')} />
        <Field label="Dose (g)" value={f.dose} onChangeText={set('dose')} />
        <Field label="Yield (g)" value={f.yield} onChangeText={set('yield')} />
        <Field label="Extraction (s)" value={f.time} onChangeText={set('time')} />
        <Field label="Group head (°C)" value={f.groupTemp} onChangeText={set('groupTemp')} />
        <Field label="Room temp (°C)" value={f.roomTemp} onChangeText={set('roomTemp')} />
        <Field label="Humidity (% RH)" value={f.humidity} onChangeText={set('humidity')} />
        <Field label="Roast date" value={f.roast} onChangeText={set('roast')} keyboardType="default" placeholder="Optional" width="full" />
      </Grid>
      <View><Label>Workload</Label><Segmented options={LOADS} value={f.workload} onChange={set('workload')} /></View>
      <View><Label>How did it taste?</Label><Segmented options={TASTES} value={f.taste} onChange={set('taste')} /></View>
      <Field label="Notes" value={f.notes} onChangeText={set('notes')} keyboardType="default" placeholder="Optional" width="full" />
      {err ? <Text style={{ color: C.bad }}>{err}</Text> : null}
      <Button title={saved ? 'Saved' : 'Save shot'} onPress={save} disabled={!!blocked} />
    </Card>
  );
}
