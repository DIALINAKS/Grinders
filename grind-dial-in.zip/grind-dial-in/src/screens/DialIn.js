import React, { useMemo, useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { C, S, R } from '../theme';
import { Card, Field, Grid, Label, Segmented, Body, H2, Note } from '../components/ui';
import { recommend, rulesFor, fmt } from '../engine';

const LOADS = [{ value: 0, label: 'Quiet' }, { value: 1, label: 'Steady' }, { value: 2, label: 'Busy' }];

/** The main screen: what to set the grinder dial and dose time to for the next shot. */
export default function DialIn({ grinder, shots }) {
  const last = shots[shots.length - 1];
  const [now, setNow] = useState(() => defaultsFrom(last));
  const [quick, setQuick] = useState({ setting: '', time: '' });

  // when the grinder or coffee changes, start again from that profile's last shot
  const profileKey = grinder ? grinder.id + '|' + (last ? last.bean : '') : '';
  useEffect(() => { setNow(defaultsFrom(last)); setQuick({ setting: last ? String(last.setting) : '', time: '' }); }, [profileKey]);

  const rules = rulesFor(grinder);
  const r = useMemo(() => recommend({ shots, rules, now, quick }), [shots, grinder, now, quick]);
  const set = k => v => setNow(p => ({ ...p, [k]: v }));

  return (
    <View style={{ gap: S.lg }}>
      <Card>
        <H2>Settings for your next shot</H2>
        <Grid>
          <Field label="Target extraction (s)" value={now.target} onChangeText={set('target')} />
          <Field label="Dose (g)" value={now.dose} onChangeText={set('dose')} />
          <Field label="Target yield (g)" value={now.yield} onChangeText={set('yield')} />
          <Field label="Group head (°C)" value={now.groupTemp} onChangeText={set('groupTemp')} />
          <Field label="Room temp (°C)" value={now.roomTemp} onChangeText={set('roomTemp')} />
          <Field label="Humidity (% RH)" value={now.humidity} onChangeText={set('humidity')} />
        </Grid>
        <View>
          <Label>Workload now</Label>
          <Segmented options={LOADS} value={Number(now.workload)} onChange={set('workload')} />
        </View>
        <View>
          <Label>Quick adjust (optional)</Label>
          <Grid>
            <Field label="Grinder on now" value={quick.setting} onChangeText={v => setQuick(q => ({ ...q, setting: v }))} />
            <Field label="Shot just pulled (s)" value={quick.time} onChangeText={v => setQuick(q => ({ ...q, time: v }))} placeholder="Optional" />
          </Grid>
        </View>
      </Card>

      <Readout r={r} now={now} />
    </View>
  );
}

function defaultsFrom(last) {
  return {
    target: '28',
    dose: last && last.dose != null ? String(last.dose) : '18',
    yield: last && last.dose != null ? String(+(last.dose * 2).toFixed(1)) : '36',
    roomTemp: last && last.roomTemp != null ? String(last.roomTemp) : '',
    humidity: last && last.humidity != null ? String(last.humidity) : '',
    groupTemp: last && last.groupTemp != null ? String(last.groupTemp) : '',
    workload: last && last.workload != null ? last.workload : 1,
  };
}

function Readout({ r, now }) {
  if (r.status === 'no-shots') return <Note>Log a shot to get started. The app learns from every shot you log on this grinder and coffee.</Note>;
  if (r.status === 'need-more') return <Note>Fill in this grinder's rules, or log a second shot at a different grind setting.</Note>;
  if (r.status === 'no-target') return <Note>Enter a target extraction time.</Note>;
  if (r.status === 'flat') return <Note tone="warn">Changing the grind isn't moving the time much in your shots yet ({fmt(r.secondsPerNotch, 2)} s per notch). Try shots further apart on the dial.</Note>;

  const d = r.dial, ds = r.dose;
  return (
    <View style={{ gap: S.md }}>
      <View style={st.readings}>
        <View style={st.reading}>
          <Text style={st.rLabel}>1 · GRINDER DIAL</Text>
          <Text style={st.big}>{d.text}{d.range ? <Text style={st.small}>  ± {d.range}</Text> : null}</Text>
          <Text style={st.rSub}>{d.words}</Text>
          <Text style={st.rSub}>{d.anchor} → <Text style={st.strong}>{d.move}</Text></Text>
          {d.capped ? <Text style={[st.rSub, { color: C.warn }]}>Capped at one notch. Pull a shot here and check before going further.</Text> : null}
        </View>
        <View style={st.reading}>
          <Text style={st.rLabel}>2 · DOSE TIME</Text>
          <Text style={st.big}>{ds.seconds != null ? fmt(ds.seconds) : '–'}<Text style={st.small}>{ds.seconds != null ? ' s' : ''}</Text></Text>
          {ds.preset ? <Text style={[st.rSub, st.strong]}>{ds.preset.text}</Text> : null}
          {ds.lastSeconds != null
            ? <Text style={st.rSub}>Last shot {fmt(ds.lastSeconds)} s gave {fmt(ds.lastGrams)} g → <Text style={st.strong}>{ds.change === 0 ? 'hold' : (ds.change > 0 ? '+' : '') + fmt(ds.change) + ' s'}</Text> for {fmt(parseFloat(now.dose))} g</Text>
            : <Text style={st.rSub}>Log a shot with its doser time to get this.</Text>}
          {ds.unknownPerNotch ? <Text style={[st.rSub, { color: C.warn }]}>The grind is changing, but the dose time change per notch isn't known yet. Add it in Rules.</Text> : null}
        </View>
      </View>

      <Body muted>Both settings aim for <Text style={st.strong}>{fmt(parseFloat(now.target))} s extraction</Text> with {fmt(parseFloat(now.dose))} g in.</Body>

      {d.breakdown.length ? (
        <Card>
          <Label>Why it's moving</Label>
          {d.breakdown.map((b, i) => (
            <View key={i} style={st.whyRow}>
              <Text style={st.whyText}>{b.label}</Text>
              <Text style={[st.whyText, st.strong]}>{b.move}</Text>
            </View>
          ))}
        </Card>
      ) : null}

      <View style={st.chips}>
        <Chip>{r.shotsUsed} shots</Chip>
        <Chip>{fmt(r.secondsPerNotch)} s per notch</Chip>
        <Chip>{fmt(r.secondsPerMark)} s per mark · {fmt(r.secondsPerQuarter, 2)} s per ¼</Chip>
        {ds.perNotch != null ? <Chip>dose time {ds.perNotch > 0 ? '+' : ''}{fmt(ds.perNotch, 2)} s per notch finer ({ds.perNotchSource})</Chip> : null}
        {r.fitPercent != null ? <Chip>fit {r.fitPercent}%</Chip> : <Chip>Log a 3rd shot for a ± range</Chip>}
      </View>
      <Body muted>{r.direction}{r.outside ? ' This is outside the settings you\'ve tried, so treat it as a first guess.' : ''} {r.tasteHint}</Body>
    </View>
  );
}

function Chip({ children }) {
  return <View style={st.chip}><Text style={st.chipText}>{children}</Text></View>;
}

const st = StyleSheet.create({
  readings: { flexDirection: 'row', flexWrap: 'wrap', gap: S.md },
  reading: { flexGrow: 1, flexBasis: '45%', minWidth: 150, backgroundColor: C.accentSoft, borderRadius: R.md, borderWidth: 1, borderColor: '#1D3B7A', padding: S.lg, gap: 4 },
  rLabel: { color: C.ink, fontSize: 11, fontWeight: '800', letterSpacing: 1 },
  big: { color: C.accentBright, fontSize: 52, fontWeight: '800', lineHeight: 58 },
  small: { color: C.muted, fontSize: 16, fontWeight: '600' },
  rSub: { color: C.muted, fontSize: 13, lineHeight: 18 },
  strong: { color: C.ink, fontWeight: '700' },
  whyRow: { flexDirection: 'row', justifyContent: 'space-between', gap: S.md },
  whyText: { color: C.muted, fontSize: 13, flexShrink: 1 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: S.sm },
  chip: { borderWidth: 1, borderColor: C.line, borderRadius: R.pill, paddingHorizontal: 10, paddingVertical: 4 },
  chipText: { color: C.muted, fontSize: 12 },
});
