import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { View, Text, Image, ScrollView, Pressable, SafeAreaView, StatusBar, Platform, KeyboardAvoidingView, StyleSheet } from 'react-native';
import { C, S, R } from './src/theme';
import { load, save, newId, EMPTY } from './src/store';
import { Chips, Label, Note } from './src/components/ui';
import {
  tierOf, usageText, activeGrinders, reconcileGrinders, shotLimitReached, rulesFor,
} from './src/engine';
import Welcome from './src/screens/Welcome';
import DialIn from './src/screens/DialIn';
import LogShot from './src/screens/LogShot';
import History from './src/screens/History';
import Rules from './src/screens/Rules';
import Account from './src/screens/Account';
import RegisterGrinder from './src/screens/RegisterGrinder';
import ArchivePick from './src/screens/ArchivePick';

const TABS = [
  { key: 'dial', label: 'Dial-in' },
  { key: 'log', label: 'Log shot' },
  { key: 'history', label: 'History' },
  { key: 'rules', label: 'Rules' },
];

export default function App() {
  const [st, setSt] = useState(null);           // saved state, null while loading
  const [view, setView] = useState('main');     // 'main' | 'account' | 'register' | 'welcome'
  const [tab, setTab] = useState('dial');

  useEffect(() => { load().then(setSt); }, []);
  const update = useCallback(fn => setSt(prev => { const next = fn(prev); save(next); return next; }), []);

  if (!st) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  /* ---------- first open: choose a plan ---------- */
  if (!st.tier || view === 'welcome') {
    return (
      <Shell>
        <Welcome bill={st.bill} onBill={b => update(s => ({ ...s, bill: b }))}
          onChoose={t => { update(s => applyTier(s, t)); setView('main'); }} />
      </Shell>
    );
  }

  const grinders = st.grinders;
  const grinder = grinders.find(g => g.id === st.grinderId) || (activeGrinders(grinders)[0] || null);
  const gShots = grinder ? st.shots.filter(s => s.grinderId === grinder.id) : [];
  const coffees = [...new Set(gShots.map(s => s.bean))];
  // '' = "New coffee" chosen: start a fresh profile; otherwise the selected coffee, or the most recent one
  const picked = grinder ? st.coffee[grinder.id] : undefined;
  const coffee = picked === '' ? '' : (picked && coffees.includes(picked) ? picked : (gShots.length ? gShots[gShots.length - 1].bean : ''));
  const profileShots = gShots.filter(s => s.bean === coffee).sort((a, b) => (a.ts < b.ts ? -1 : 1));
  const recon = reconcileGrinders(st.tier, grinders);
  const blocked = shotLimitReached(st.tier, st.shots) ? 'limit' : grinder && grinder.archived ? 'archived' : null;

  /* ---------- actions ---------- */
  const registerGrinder = (name, model) => {
    const g = { id: newId('g'), name, model, rules: {}, archived: false, createdAt: new Date().toISOString() };
    update(s => ({ ...s, grinders: [...s.grinders, g], grinderId: g.id }));
    setView('main'); setTab('rules');
  };
  const saveShot = shot => update(s => ({
    ...s, shots: [...s.shots, { ...shot, id: newId('s'), grinderId: grinder.id, grinder: grinder.name, ts: new Date().toISOString() }],
    coffee: { ...s.coffee, [grinder.id]: shot.bean },
  }));
  const deleteShot = id => update(s => ({ ...s, shots: s.shots.filter(x => x.id !== id) }));
  const changeRules = rules => update(s => ({ ...s, grinders: s.grinders.map(g => (g.id === grinder.id ? { ...g, rules } : g)) }));
  const keepGrinder = id => update(s => ({ ...s, grinderId: id, grinders: s.grinders.map(g => (g.archived ? g : { ...g, archived: g.id !== id })) }));

  /* ---------- screens ---------- */
  let body;
  if (recon.mustChoose) {
    body = <ArchivePick tier={st.tier} grinders={grinders} shots={st.shots} onKeep={keepGrinder} />;
  } else if (view === 'account') {
    body = <Account tier={st.tier} bill={st.bill} grinders={grinders} shots={st.shots}
      onBill={b => update(s => ({ ...s, bill: b }))} onTier={t => update(s => applyTier(s, t))} onBack={() => setView('main')} />;
  } else if (view === 'register' || !grinder) {
    body = (
      <View style={{ gap: S.lg }}>
        {!grinder ? <Note>Register your grinder to start. Coffees, settings and shots are kept per grinder.</Note> : null}
        <RegisterGrinder tier={st.tier} grinders={grinders} onRegister={registerGrinder}
          onClose={() => setView('main')} onSeePlans={() => setView('account')} />
      </View>
    );
  } else {
    body = (
      <View style={{ gap: S.lg }}>
        {tab === 'dial' ? <DialIn grinder={grinder} shots={profileShots} /> : null}
        {tab === 'log' ? <LogShot grinder={grinder} coffee={coffee} lastShot={profileShots[profileShots.length - 1]}
          blocked={blocked} onSave={saveShot} onSeePlans={() => setView('account')} /> : null}
        {tab === 'history' ? <History shots={profileShots} onDelete={deleteShot} readOnly={grinder.archived} /> : null}
        {tab === 'rules' ? <Rules grinder={grinder} onChange={changeRules} readOnly={grinder.archived} /> : null}
      </View>
    );
  }

  const showPickers = view === 'main' && grinder && !recon.mustChoose;
  return (
    <Shell>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={st_.scroll} keyboardShouldPersistTaps="handled">
        <View style={st_.header}>
          <Image source={require('./assets/logo.png')} style={st_.logo} />
          <View style={{ flex: 1 }}>
            <Text style={st_.title}>Grind Dial-In</Text>
            <Text style={st_.plan}><Text style={{ color: C.ink, fontWeight: '700' }}>{tierOf(st.tier).label}</Text> · {usageText(st.tier, grinders, st.shots)}</Text>
          </View>
          <Pressable onPress={() => setView(view === 'account' ? 'main' : 'account')} hitSlop={8}>
            <Text style={st_.link}>{view === 'account' ? 'Done' : 'Account'}</Text>
          </Pressable>
        </View>

        {showPickers ? (
          <View style={{ gap: S.md }}>
            <View>
              <Label>Grinder</Label>
              <Chips
                items={[...activeGrinders(grinders), ...grinders.filter(g => g.archived)].map(g => ({ key: g.id, label: g.archived ? `${g.name} · archived` : g.name, dim: g.archived }))}
                value={grinder.id} onChange={id => update(s => ({ ...s, grinderId: id }))}
                addLabel="Register" onAdd={() => setView('register')} />
            </View>
            <View>
              <Label>Coffee</Label>
              {coffees.length
                ? <Chips items={coffees.map(c => ({ key: c, label: c }))} value={coffee} onChange={c => update(s => ({ ...s, coffee: { ...s.coffee, [grinder.id]: c } }))}
                    addLabel="New coffee" onAdd={() => { update(s => ({ ...s, coffee: { ...s.coffee, [grinder.id]: '' } })); setTab('log'); }} />
                : <Text style={{ color: C.muted }}>No coffees yet. Log your first shot to add one.</Text>}
            </View>
          </View>
        ) : null}

        {body}
        <Text style={st_.foot}>Testing version · no payments · data saved on this phone</Text>
      </ScrollView>

      {showPickers ? (
        <View style={st_.tabs}>
          {TABS.map(t => (
            <Pressable key={t.key} onPress={() => setTab(t.key)} style={st_.tab} accessibilityRole="tab" accessibilityState={{ selected: tab === t.key }}>
              <View style={[st_.tabDot, tab === t.key && { backgroundColor: C.accentBright }]} />
              <Text style={[st_.tabText, tab === t.key && { color: C.ink }]}>{t.label}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </Shell>
  );
}

/** Apply a plan change: archive or restore grinders as the plan allows. Nothing is ever deleted. */
function applyTier(s, tier) {
  const next = { ...s, tier };
  const r = reconcileGrinders(tier, s.grinders);
  if (r.restore.length) next.grinders = s.grinders.map(g => (r.restore.includes(g.id) ? { ...g, archived: false } : g));
  return next;
}

function Shell({ children }) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0 }}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {children}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const st_ = StyleSheet.create({
  scroll: { padding: S.lg, gap: S.lg, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', gap: S.md },
  logo: { width: 44, height: 44, borderRadius: 11 },
  title: { color: C.ink, fontSize: 22, fontWeight: '800' },
  plan: { color: C.muted, fontSize: 13 },
  link: { color: C.accentBright, fontWeight: '700' },
  foot: { color: C.faint, fontSize: 11, textAlign: 'center' },
  tabs: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.surface, paddingBottom: Platform.OS === 'ios' ? 4 : 8, paddingTop: 8 },
  tab: { flex: 1, alignItems: 'center', gap: 4 },
  tabDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'transparent' },
  tabText: { color: C.muted, fontWeight: '600', fontSize: 13 },
});
